﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArrayFun
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int ARRAYSIZE = 10;

        int[] numbersArray = new int[ARRAYSIZE];
        int[] originalArray = new int[ARRAYSIZE];

        int sum = 0;

        private void help(object sender, EventArgs e)
        {
            printOutHelpInfo();
        }

        private void printOutHelpInfo()
        {
            string helpstr = "this is the help button, put what you please creator";
            MessageBox.Show(helpstr, "help instructions");
        }

        private void Exit(object sender, EventArgs e)
        {
            quitProgram();
        }

        private void quitProgram()
        {
            DialogResult doAgain = MessageBox.Show("do you want to run this program again? Y/N", "exit", MessageBoxButtons.YesNo);
            if (doAgain == DialogResult.Yes)
            {
                Close();
            }
            else
            {
                generateNewArray();
            }
            
        }

        private void Clear(object sender, EventArgs e)
        {
            clearListBox();
        }

        private void clearListBox()
        {
            generateNewArray();
        }

        private void generateNewArray()
        {
            Random rand = new Random();

            textBox1.Items.Clear();

            for (int lcv = 0; lcv < numbersArray.Length; ++lcv)
            {
                numbersArray[lcv] = rand.Next(1, 101);
                originalArray[lcv] = numbersArray[lcv];
                textBox1.Items.Add(numbersArray[lcv]);
            }
        }

        private void Search(object sender, EventArgs e)
        {
            searchButton();
        }

        private void searchButton()
        {
            int numFound = 0;
            int number = 0;

            if (searchTextBox.Text == "")
            {
                badInput();
            }

            number = Convert.ToInt32(searchTextBox.Text);

            if ((number < 1) || (number > 100))
            {
                badInput();
            }

            numFound = Array.BinarySearch(numbersArray, number);

            if (numFound < 0)
            {
                badInput();
            }
            else
            {
                MessageBox.Show("IT WAS FOUND AT: " + numFound.ToString(), "num found");
                searchTextBox.Text = "";
            }
        }

        private void badInput()
        {
            MessageBox.Show("Not Found", "LOL", MessageBoxButtons.OK);
            searchTextBox.Text = "";
            return;
        }

        private void sortDecending(object sender, EventArgs e)
        {
            textBox1.Items.Clear();
            sortDecending1();
        }

        private void sortDecending1()
        {
            Array.Sort(numbersArray);
            Array.Reverse(numbersArray);

            sortingArrays();
        }

        private void sortAscending(object sender, EventArgs e)
        {
            textBox1.Items.Clear();
            sortAscending1();
        }

        private void sortAscending1()
        {
            Array.Sort(numbersArray);

            sortingArrays();
        }

        private void sortingArrays()
        {
            for (int lcv = 0; lcv < numbersArray.Length; ++lcv)
            {
                textBox1.Items.Add(numbersArray[lcv]);
            }
        }

        private void displayAvg(object sender, EventArgs e)
        {
            sumAndAvgOfArrayElements();
        }
        

        private void sumAndAvgOfArrayElements()
        {
            
            double avg = 0.0;

            for (int lcv = 0; lcv < numbersArray.Length; ++lcv)
            {
                sum += numbersArray[lcv];
            }

            avg = (double)sum / numbersArray.Length;

            MessageBox.Show("the avg is " + avg.ToString("f2"), "average of size array element");
        }

        private void displaySum(object sender, EventArgs e)
        {
            sumOfArrayElements();
        }

        private void sumOfArrayElements()
        {
            for (int lcv = 0; lcv < numbersArray.Length; ++lcv)
            {
                sum += numbersArray[lcv];
            }

            MessageBox.Show("the sum is " + sum.ToString("f2"), "sum of size array element");
        }

        private void displayHighest(object sender, EventArgs e)
        {
            displayTheHighest();
        }

        private void displayTheHighest()
        {
            Array.Sort(numbersArray);
            Array.Reverse(numbersArray);

            MessageBox.Show("the highest: " + numbersArray[0].ToString(), "BOOM");
        }

        private void displayLowest(object sender, EventArgs e)
        {
            displayTheLowest();
        }

        private void displayTheLowest()
        {
            Array.Sort(numbersArray);

            MessageBox.Show("the lowest: " + numbersArray[0].ToString(), "BOOM");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            generateNewArray();
        }

        private void displayArray(object sender, EventArgs e)
        {
            displayOriginalArray();
        }

        private void displayOriginalArray()
        {
            textBox1.Items.Clear();

            generateNewArray();
        }
    }
}
