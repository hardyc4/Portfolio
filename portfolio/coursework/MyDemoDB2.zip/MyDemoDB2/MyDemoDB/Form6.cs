﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDemoDB
{
    public partial class Form6 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Chris\Desktop\C#\MyDemoDB2\MyDemoDB\demoDB.mdf;Integrated Security=True";
        int cId = 0;
        public Form6()
        {
            InitializeComponent();
            FillComboBox();
        }

        private void FillComboBox()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "SELECT *  FROM customers ; ";
            conn.Open();
            SqlCommand command = new SqlCommand(sql, conn);
            SqlDataReader dataReader;
            try
            {
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    string cName = dataReader["CompanyName"].ToString();
                    textBox1.Items.Add(cName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            conn.Close();
        }

        private void comboBoxDeleteCustomer_SelectedIdexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "SELECT *  FROM customers WHERE companyName='" + textBox1.Text + "' ;";
            conn.Open();
            SqlCommand command = new SqlCommand(sql, conn);
            SqlDataReader dataReader;
            try
            {
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    cId = Convert.ToInt32(dataReader["CustomerID"].ToString());
                    string compName = dataReader["companyName"].ToString();
                    string conName = dataReader["contactName"].ToString();
                    string pho = dataReader["phone"].ToString();
                    textBox1.Text = cId.ToString();
                    textBox2.Text = compName;
                    textBox3.Text = conName;
                    textBox4.Text = pho;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            formLogin login = new formLogin();
            login.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool keepGoing = true;
            if (keepGoing)
            {
                DoYouReallyWantToDeleteThisCustomer();
            }
            if (keepGoing)
            {
                try
                {
                    SqlConnection conn = new SqlConnection(connectionString);
                    SqlCommand command;
                    SqlDataAdapter dataAdapter = new SqlDataAdapter();
                    string sql = "DELETE FROM customers WHERE customerid = '" + cId + "' ;";
                    command = new SqlCommand(sql, conn);
                    conn.Open();
                    dataAdapter.DeleteCommand = new SqlCommand(sql, conn);
                    dataAdapter.DeleteCommand.ExecuteNonQuery();
                    command.Dispose();
                    conn.Close();
                    MessageBox.Show("Record Deleted", "CURRENT RECORD DELETED",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                    clearDeleteForm();
                    textBox1.Items.Remove(textBox1.SelectedItem);
                    textBox1.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return;
        }
        private bool DoYouReallyWantToDeleteThisCustomer()
        {
            string msg = "Do You Really Want To Delete This Customer?";
            msg += "\nNote: You will NOT Be Able To delete The";
            msg += "\ncustomer if they have any outstanding orders!";

            if (MessageBox.Show(msg, "DELETE CURRENT CUSTOMER???",
                                    MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Information) ==
                                    DialogResult.Yes)
            {
                return true;
            }
            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearDeleteForm();
            return;
        }

        private void clearDeleteForm()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox1.Focus();
        }
    }
}