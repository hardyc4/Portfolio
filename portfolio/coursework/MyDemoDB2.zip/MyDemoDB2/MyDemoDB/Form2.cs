﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDemoDB
{
    public partial class Form2 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Chris\Desktop\C#\MyDemoDB2\MyDemoDB\demoDB.mdf;Integrated Security=True";
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearInsertForm();
            return;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            formLogin login = new formLogin();
            login.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool keepGoing = true;
            keepGoing = checkForNullCompanyName();
            if (keepGoing)
            {
                string company = textBox1.Text.ToString();
                string contact = textBox2.Text.ToString();
                string phone = textBox3.Text.ToString();
                try
                {
                    SqlConnection conn = new SqlConnection(connectionString);
                    conn.Open();
                    string sql = "INSERT INTO customers (companyName, contactName, phone) VALUES ('" + company + "','" + contact + "'.'" + phone + "') ;";
                    SqlCommand command = new SqlCommand(sql, conn);
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    dataAdapter.InsertCommand = new SqlCommand(sql, conn);
                    dataAdapter.InsertCommand.ExecuteNonQuery();
                    MessageBox.Show("Record Inserted", "BOOM",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    command.Dispose();
                    conn.Close();
                    clearInsertForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ERROR OCCURRED", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Record Insert Aborted", "NO RECORD INSERTED!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
        }
        private bool checkForNullCompanyName()
        {
            if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("Company Name CANNOT Be Empty!", "EMPTY COMPANY NAME",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                textBox1.Focus();
                return false;
            }
            return true;
        }
        private void clearInsertForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox1.Focus();
        }
    }
}
