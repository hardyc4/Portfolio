﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RecordStoreProject.Models
{
    public class GenreMetadata
    {
        [StringLength(50)]
        [Required(ErrorMessage = "A Genre is required")]
        [Display(Name = "Genre Name")]
        public string GenreName;
    }

    public class ArtistMetadata
    {
        [StringLength(100)]
        [Required(ErrorMessage = "A Artist name is required")]
        [Display(Name = "Artist Name")]
        public string ArtistName;
    }

    public class AlbumMetadata
    {
        [StringLength(100)]
        [Required(ErrorMessage = "A Album name is required")]
        [Display(Name = "Album Name")]
        public string AlbumName;

        [Range(1, 100, ErrorMessage = "Album Price Must Be Between 1 and 100")]
        [Display(Name = "Album Price")]

        public decimal AlbumPrice;
    }
}