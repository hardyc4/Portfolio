﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDemoDB
{
    public partial class formLogin : Form
    {
        public formLogin()
        {
            InitializeComponent();
        }

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Chris\Desktop\C#\MyDemoDB\MyDemoDB\demoDB.mdf;Integrated Security=True";
        SqlConnection conn = null;
        SqlCommand command = null;
        SqlDataReader dataReader = null;
        string sql = "";
        string output = "";

        private void button1_Click(object sender, EventArgs e)
        {
            output = "";
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                sql = "SELECT customerid, Companyname, contactname, phone FROM customers";
                command = new SqlCommand(sql, conn);
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    output = output + dataReader.GetValue(0) + " " + dataReader.GetValue(1) + " " +
                        dataReader.GetValue(2) + " " + dataReader.GetValue(3) + "\n\n";
                }
                MessageBox.Show(output, "Customer Records",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            output = "";
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                sql = "SELECT orderid, customerid, orderdate, orderquantity FROM orders";
                command = new SqlCommand(sql, conn);
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    output = output + dataReader.GetValue(0) + " " + dataReader.GetValue(1) + " " +
                        dataReader.GetValue(2) + " " + dataReader.GetValue(3) + "\n\n";
                }
                MessageBox.Show(output, "Order Records",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonInsertCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 insertCustomer = new Form2();
            insertCustomer.ShowDialog();
        }

        private void buttonInsertOrder_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 insertOrder = new Form3();
            insertOrder.ShowDialog();
        }

        private void buttonUpdateCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 updateCustomer = new Form4();
            updateCustomer.ShowDialog();
        }

        private void buttonUpdateOrder_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 updateOrder = new Form5();
            updateOrder.ShowDialog();
        }

        private void buttonDeleteCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 deleteCustomer = new Form6();
            deleteCustomer.ShowDialog();
        }

        private void buttonDeleteOrder_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 deleteOrder = new Form7();
            deleteOrder.ShowDialog();
        }
    }
}