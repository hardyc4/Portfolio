﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDemoDB
{
    public partial class Form4 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Chris\Desktop\C#\MyDemoDB2\MyDemoDB\demoDB.mdf;Integrated Security=True";
        int cId = 0;
        public Form4()
        {
            InitializeComponent();
            FillComboBox();
        }
        private void FillComboBox()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "SELECT *  FROM customers ; ";
            conn.Open();
            SqlCommand command = new SqlCommand(sql, conn);
            SqlDataReader dataReader;
            try
            {
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    cId = Convert.ToInt32(dataReader["CustomerID"].ToString());
                    textBox1.Items.Add(cId);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            formLogin login = new formLogin();
            login.ShowDialog();
        }
        private void textBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "SELECT * FROM customers WHERE customerID='" + textBox1.Text + "' ;";
            conn.Open();
            SqlCommand command = new SqlCommand(sql, conn);
            SqlDataReader dataReader;
            try
            {
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    cId = Convert.ToInt32(dataReader["CustomerID"].ToString());
                    string comName = dataReader["companyName"].ToString();
                    string conName = dataReader["contactName"].ToString();
                    string phone = dataReader["phone"].ToString();
                    textBox1.Text = cId.ToString();
                    textBox3.Text = comName;
                    textBox4.Text = conName;
                    textBox5.Text = phone;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool keepGoing = true;
            if (keepGoing)
            {
                DoYouReallyWantToUpdateThisCustomer();
            }
            if (keepGoing)
            {
                try
                {
                    SqlConnection conn = new SqlConnection(connectionString);
                    SqlCommand command;
                    SqlDataAdapter dataAdapter = new SqlDataAdapter();
                    string sql = "UPDATE Customers SET CompanyName = '" + textBox1.Text.ToString() +
                                "', ContactName = '" + textBox2.Text.ToString() +
                                "', Phone = '" + textBox3.Text.ToString() +
                                "'WHERE customerID = '" + cId.ToString() + "'; ";
                    command = new SqlCommand(sql, conn);
                    conn.Open();
                    dataAdapter.UpdateCommand = new SqlCommand(sql, conn);
                    dataAdapter.UpdateCommand.ExecuteNonQuery();
                    command.Dispose();
                    conn.Close();
                    MessageBox.Show("Current Customer Record Update",
                                    "CUSTOMER RECORD UPDATED",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                    clearUpdateForm();
                    textBox1.Items.Remove(textBox1.SelectedItem);
                    textBox1.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return;
        }

        private bool DoYouReallyWantToUpdateThisCustomer()
        {
            string msg = "Do Your Really Wanna Update This Customer?";
            if (MessageBox.Show(msg,
                                "UPDATE CURRENT CUSTOMER???",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Information) ==
                                DialogResult.Yes)
            {
                return true;
            }
            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearUpdateForm();
            return;
        }
        public void clearUpdateForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}
