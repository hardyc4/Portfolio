﻿using System;
using static System.Console;

namespace BankProject
{
    class Program
    {
        // #1
        public static string firstName { get; set; }
        public static string lastName { get; set; }
        public static int acctNumber { get; set; }
        public static double initialBal { get; set; }

        // #2 a
        // Just type "fillWithDefaults();" at the top of main if you want to run this one.
        public static void fillWithDefaults()
        {
            Random rnd = new Random();

            firstName = ("UFirst");
            lastName = ("ULast");
            acctNumber = rnd.Next(1001, 10000);
            initialBal = 25;

            Write(firstName + " " + lastName + "\nAccount Number: " + acctNumber + "\nInitial Balence: " + initialBal);
            ReadLine();
        }

        // #2 b
        public static void yourInput()
        {
            Write("First Name: ");
            firstName = Console.ReadLine();
            Write("Last Name: ");
            lastName = Console.ReadLine();
            Write("Account Number: ");
            acctNumber = Convert.ToInt32(ReadLine());
            Write("Balence: ");
            initialBal = Convert.ToInt32(ReadLine());

            Write(firstName + " " + lastName + "\nAccount Number: " + acctNumber + "\nInitial Balence: " + initialBal);
            ReadLine();
        }

        // #3
        string FirstName
        {
            get { return firstName; }
            set {  }
        }
        string LastName
        {
            get { return lastName; }
            set {  }
        }
        int AcctNumber
        {
            get { return acctNumber; }
            set {  }
        }
        double InitialBal
        {
            get { return initialBal; }
            set {  }
        }

        // #4
        // Just type "withOrDep();" at the top of main if you want to run this one.
        private static void withOrDep()
        {
            string withOrDep;
            int withMoney;
            int depMoney;

            Write("Would you like to Withdraw or Deposit? ");
            withOrDep = Console.ReadLine().ToUpper();
            if (withOrDep == "WITHDRAW")
            {
                Write("How Much would you like to withdraw? ");
                withMoney = Convert.ToInt32(ReadLine());
                if (withMoney >= 25)
                {
                    Write("Too Low");
                    //withOrDep();
                }
                initialBal = (initialBal - withMoney);
            }
            if (withOrDep == "DEPOSIT");
            {
                Write("How Much would you like to Deposit? ");
                depMoney = Convert.ToInt32(ReadLine());
                initialBal = (initialBal + depMoney);
            }
        }

        // #5
        // Just type "bankAccounts();" at the top of main if you want to run this one.
        private static void bankAccounts()
        {
            string choose;

            WriteLine("1 = Part A | 2 = Part B | 3 = Part C | 4 = Part D");
            WriteLine("Pick One!");
            choose = Console.ReadLine();
            if (choose == "1")
            {
                fillWithDefaults();
            }
            if (choose == "2")
            {
                yourInput();
            }
            if (choose == "3")
            {
                yourInput();
            }
            if (choose == "4")
            {
                yourInput();
            }
            else
            {
                Write("try again");
            }
        }

        // -----------MAIN---------------
        static void Main(string[] args)
        {
            bankAccounts();
        }
        // ------------------------------


    }
}
