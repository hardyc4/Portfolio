﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOT2inclass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const double MINHOURS = 0.0;
        const double MAXHOURS = 84.0;
        const double MINRATE = 0.0;
        const double MAXRATE = 250.0;
        const double MAXNONOT = 40.0;
        const double OTRATE = 1.5;

        string firstName = "";
        string lastName = "";
        double hoursWorked = 0.0;
        double hourlyRate = 0.0;
        double grossPay = 0.0;
        double totGross = 0.0;


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void clear(object sender, EventArgs e)
        {
            fname.Text = "";
            lname.Text = "";
            hours.Text = "";
            rate.Text = "";
            grosspaytext.Text = "";
            total.Text = "";
        }

        private void calculate(object sender, EventArgs e)
        {
            firstName = fname.Text;
            lastName = lname.Text;
            hoursWorked = Convert.ToDouble(hours.Text);
            hourlyRate = Convert.ToDouble(rate.Text);

            if (hoursWorked <= MAXNONOT)
            {
                grossPay = hoursWorked * hourlyRate;
            }
            else
            {
                grossPay = (MAXNONOT * hourlyRate) + (hoursWorked - MAXNONOT) * hourlyRate * OTRATE;
            }

            totGross += grossPay;

            grosspaytext.Text = grossPay.ToString("c");
            total.Text = totGross.ToString("c");

            fname.Text = "";
            lname.Text = "";
            hours.Text = "";
            rate.Text = "";
        }

        private void exit(object sender, EventArgs e)
        {
            Close();
        }
    }
}
