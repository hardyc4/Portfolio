﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDemoDB
{
    public partial class Form3 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Chris\Desktop\C#\MyDemoDB2\MyDemoDB\demoDB.mdf;Integrated Security=True";
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearInsertForm();
            return;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            formLogin login = new formLogin();
            login.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool keepGoing = true;
            keepGoing = checkForNullCustomerID();
            if (keepGoing)
            {
                string id = textBox1.Text.ToString();
                string date = textBox2.Text.ToString();
                string quantity = textBox3.Text.ToString();
                try
                {
                    SqlConnection conn = new SqlConnection(connectionString);
                    conn.Open();
                    string sql = "INSERT INTO orders (customerid, orderDate, orderQuantity) VALUES ('" + id + "','" + date + "'.'" + quantity + "') ;";
                    SqlCommand command = new SqlCommand(sql, conn);
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                    dataAdapter.InsertCommand = new SqlCommand(sql, conn);
                    dataAdapter.InsertCommand.ExecuteNonQuery();
                    MessageBox.Show("Record Inserted", "BOOM",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    command.Dispose();
                    conn.Close();
                    clearInsertForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ERROR OCCURRED", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Record Insert Aborted", "NO RECORD INSERTED!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
        }
        private bool checkForNullCustomerID()
        {
            if (textBox1.Text.Trim() == "")
            {
                MessageBox.Show("Company Name CANNOT Be Empty!", "EMPTY COMPANY NAME",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                textBox1.Focus();
                return false;
            }
            return true;
        }
        private void clearInsertForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox1.Focus();
        }
    }
}
