﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyDemoDB
{
    public partial class Form5 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Chris\Desktop\C#\MyDemoDB2\MyDemoDB\demoDB.mdf;Integrated Security=True";
        int oId = 0;
        public Form5()
        {
            InitializeComponent();
            FillComboBox();
        }

        private void FillComboBox()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "SELECT *  FROM orders ; ";
            conn.Open();
            SqlCommand command = new SqlCommand(sql, conn);
            SqlDataReader dataReader;
            try
            {
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    oId = Convert.ToInt32(dataReader["OrderID"].ToString());
                    textBox1.Items.Add(oId);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            formLogin login = new formLogin();
            login.ShowDialog();
        }

        private void textBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            string sql = "SELECT * FROM orders WHERE orderID='" + textBox1.Text + "' ;";
            conn.Open();
            SqlCommand command = new SqlCommand(sql, conn);
            SqlDataReader dataReader;
            try
            {
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    oId = Convert.ToInt32(dataReader["OrderID"].ToString());
                    string cusID = dataReader["customerID"].ToString();
                    string date = dataReader["orderDate"].ToString();
                    string quantity = dataReader["orderQuantity"].ToString();
                    textBox1.Text = oId.ToString();
                    textBox3.Text = cusID;
                    textBox4.Text = date;
                    textBox5.Text = quantity;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool keepGoing = true;
            if (keepGoing)
            {
                DoYouReallyWantToUpdateThisOrder();
            }
            if (keepGoing)
            {
                try
                {
                    SqlConnection conn = new SqlConnection(connectionString);
                    SqlCommand command;
                    SqlDataAdapter dataAdapter = new SqlDataAdapter();
                    string sql = "UPDATE orders SET OrderName = '" + textBox1.Text.ToString() +
                                "', orderDate = '" + textBox2.Text.ToString() +
                                "', orderQuantity = '" + textBox3.Text.ToString() +
                                "'WHERE customerID = '" + oId.ToString() + "'; ";
                    command = new SqlCommand(sql, conn);
                    conn.Open();
                    dataAdapter.UpdateCommand = new SqlCommand(sql, conn);
                    dataAdapter.UpdateCommand.ExecuteNonQuery();
                    command.Dispose();
                    conn.Close();
                    MessageBox.Show("Current order Record Update",
                                    "order RECORD UPDATED",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                    clearUpdateForm();
                    textBox1.Items.Remove(textBox1.SelectedItem);
                    textBox1.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            return;
        }

        private bool DoYouReallyWantToUpdateThisOrder()
        {
            string msg = "Do Your Really Wanna Update This order?";
            if (MessageBox.Show(msg,
                                "UPDATE CURRENT order???",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Information) ==
                                DialogResult.Yes)
            {
                return true;
            }
            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clearUpdateForm();
            return;
        }

        public void clearUpdateForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}
