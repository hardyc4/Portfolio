package org.insideranken.christopher_hardy.fortuneteller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Scanner;

public class theFortune extends AppCompatActivity {

    private TextView textFortune;
    private Button buttonHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_fortune);

        textFortune = (TextView) findViewById(R.id.textFortune);
        buttonHome = (Button) findViewById(R.id.buttonHome);

        Scanner in = new Scanner(System.in);

        //String array
        final String[] fortunes = {
                "A friend asks only for your time not your money",
                "If you refuse to accept anything but the best, you very often get it",
                "Hard work pays off in the future, laziness pays off now",
                "Change can hurt, but it leads a path to something better",
                "You learn from your mistakes... You will learn a lot today",
                "A dream you have will come true",
                "You will become great if you believe in yourself",
                "You already know the answer to the questions lingering inside your head",
                "You can make your own happiness",
                "The greatest risk is not taking one",
                "You are very talented in many ways",
                "A stranger, is a friend you have not spoken to yet"
        };

        int length = fortunes.length;

        for(int i = 0; i < length; i++){
            int index = (int)(Math.random() * length);
            textFortune.setText(fortunes[index]);
        }

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
